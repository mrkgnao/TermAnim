import java.util.Scanner;

public class StrSort {
    static void main() {
        boolean debug = false;
        char ch = 0;
        Scanner sc = new Scanner(System.in);
        String[] in, out;
        
        while(ch != 'q') {
            U.print("\n[s]election sort, [b]ubble sort, " +
                "turn [d]ebug " + (debug ? "off" : "on") +
                ", [q]uit: ");
            ch = sc.nextLine().charAt(0);
            switch(ch) {
                case 'd':
                    debug = !debug;
                    U.println("debug is now " + (debug ? "on" : "off"));
                    break;
                case 'q':
                    break;   
                case 'b':
                    U.print("Enter strings, separated by semicolons: ");
                    in = sc.nextLine().split(";");
                    out = StrBubbleSort.sort(in, debug);
                    U.print("Sorted array: ");
                    U.printStrArray(out);
                    break;
                case 's':
                    U.print("Enter strings, separated by semicolons: ");
                    in = sc.nextLine().split(";");
                    out = StrSelSort.sort(in, debug);
                    U.print("Sorted array: ");
                    U.printStrArray(out);
                    break;
            }
        }
    }

}
