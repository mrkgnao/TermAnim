import java.util.Scanner;

class Stack {
    int top;
    int size;
    int[] arr;

    int pushes, pops;
    Scanner sc = new Scanner(System.in);

    Stack(int size) {
        this.size = size;
        top = -1;
        arr = new int[size];
    }

    boolean empty() {
        return top == -1;
    }

    boolean full() {
        return top == size - 1;
    }

    // Print the array.
    // This includes a bit of hopefully useful information, unlike info().
    void disp() {
        p("[");
        if(empty()) p("|");
        
        for(int i = 0; i < size; ++i) {
            p(arr[i] + "");
            if(i == top) p("|");
            p(i == size - 1 ? "" : " ");
        }
        pl("] top = " + top + " size = " + size);
    }

    // Add an element.
    // Takes input as an argument. (This is for the Fibonacci program.)
    void push(int elem) {
        if(full()) {
            pl("Error: stack full");
        } else {
            arr[++top] = elem;
            ++pushes;
        }
        //disp();
    }
    
    // Add an element. Takes input from user.
    // Advances rear pointer by 1.
    void push() {
        if(full()) {
            pl("Error: stack full");
        } else {
            p("Enter element: ");
            int elem = sc.nextInt();
            arr[++top] = elem;

            ++pushes;
        }
        //disp();
    }

    // Remove an element.
    // Advances the front pointer by 1.
    int pop() {
        int val = Integer.MIN_VALUE;
        if(empty()) {
            pl("Error: stack empty");
        } else {
            val = arr[top--];
            pl("Value: " + val);

            ++pops;
        }
        //disp();
        return val;
    }

    void main() {
        pl("Advanced Packaged Integrated Stack Solution v3.14"); // I had to, sorry
        pl("-------------------------------------------------");

        char ch = 'a';
        while(ch != 'q') {
            p("\n[p]ush, p[o]p, [i]nfo, [q]uit | enter choice: ");
            ch = sc.next().charAt(0);

            switch(ch) {
                case 'p':
                    push(); break;
                case 'o':
                    pop(); break;
                case 'i':
                    info(); break;
                case 'q':
                    break;
            }
        }

        info();
        p("\nTo infinity and beyond!");
    }

    void p(String s) { System.out.print(s + ""); }

    void pl(String s) { System.out.println(s + ""); }
    
    // ------------------- Useless nonsense -----------------
    // ----------------- Hic abundant leones ----------------
    
    // Percentage of the array in use.
    String pcInUse() {
        int num = empty() ? 0 : top + 1;
        return String.format("%.2f", 100.0 * num / size) + "% (" + num + " of " + size + ")";
    }

    // Percentage free.
    String pcAvail() {
        int num = full() ? 0 : size - top - 1;
        return String.format("%.2f", 100.0 * num / size) + "% (" + num + " of " + size + ")";
    }

    // Display all sorts of useless info.
    void info() {
        disp();
        p("size: " + size);
        p(", top: " + top);

        p(" | pushes: " + pushes);
        p(", pops: " + pops);
        p(", total ops: " + (pushes + pops));    

        p(" | in use: " + pcInUse());
        pl(", available: " + pcAvail());
    }
}
