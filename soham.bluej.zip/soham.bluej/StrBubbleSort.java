import java.util.Scanner;

public class StrBubbleSort {
    static String[] sort(final String[] in, final boolean debug) {
        String[] cpy = in;   // arrays are passed by reference, don't modify the input
        int len = in.length;
        String swap = "";

        //Main loop
        for(int i = 0; i < len; ++i) {
            for(int j = 0; j < len - i - 1; ++j) {
                if(cpy[j + 1].compareTo(cpy[j]) < 0) { 
                    // wrong order, swap them
                    swap       = cpy[j + 1];
                    cpy[j + 1] = cpy[j];
                    cpy[j]     = swap;
                }
                
                if(debug) {
                    Utils.print("i " + i + ", j: " + j + ", array: ");
                    Utils.printStrArray(cpy);
                }
            }

        }
        return cpy;
    }
}
