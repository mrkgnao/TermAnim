public class ReverseFibonacciNumbers {
   void main(int l) {
       int a = 1, b = 1, c = 2;
       Stack st = new Stack(l);
       
       while(!st.full()) {
           st.push(a);
           a = b;
           b = c;
           c = a + b;
       }
       
       while(!st.empty()) {
           st.pop();
       }
   }
}
