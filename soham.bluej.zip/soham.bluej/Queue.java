import java.util.Scanner;

class Queue {
    int[] arr;
    int size;
    int r, f;
    int enqs, deqs;
    Scanner sc = new Scanner(System.in);

    Queue(int size) {
        this.size = size;
        arr = new int[size];
        f = -1;
        r = -1;

        main();
    }

    boolean empty() {
        return (f == -1 && r == -1) || (f > r);
    }

    boolean full() {
        return r == size - 1;
    }

    // Percentage of the array that is unusable.
    String pcLost() {
        int num = Math.max(0, f);
        return String.format("%.2f", 100.0 * num / size) + "% (" + num + " of " + size + ")";
    }

    // Percentage of the array in use.
    String pcInUse() {
        int num = empty() ? 0 : r - f + 1;
        return String.format("%.2f", 100.0 * num / size) + "% (" + num + " of " + size + ")";
    }

    // Percentage free.
    String pcAvail() {
        int num = full() ? 0 : size - r - 1;
        return String.format("%.2f", 100.0 * num / size) + "% (" + num + " of " + size + ")";
    }

    // Print the array.
    // This includes a bit of hopefully useful information, unlike info().
    void disp() {
        p("f = " + f + " ");
        p("[");
        for(int i = 0; i < size; ++i) {
            if(i == f) p("<");
            p(arr[i] + "");
            if(i == r) p(">");
            p(i == size - 1 ? "" : " ");
        }
        pl("] r = " + r + " size = " + size);
    }

    // Display all sorts of useless info.
    void info() {
        disp();
        p("size: " + size);
        p(", front: " + f);
        p(", rear: " + r);

        p(" | enqueues: " + enqs);
        p(", dequeues: " + deqs);
        p(", total ops: " + (enqs + deqs));    

        p(" | in use: " + pcInUse());
        p(", available: " + pcAvail());
        pl(", lost: " + pcLost());
    }

    // Add an element.
    // Advances rear pointer by 1.
    void enq() {
        if(full()) {
            pl("Error: queue full");
        } else {
            if(f == -1)  { f++; } 
            p("Enter element: ");
            int elem = sc.nextInt();
            arr[++r] = elem;

            ++enqs;
        }
        disp();
    }

    // Remove an element.
    // Advances the front pointer by 1.
    void deq() {
        if(empty()) {
            pl("Error: queue empty");
        } else {
            pl("Value: " + arr[f++]);

            ++deqs;
        }
        disp();
    }

    void main() {
        pl("Advanced Packaged Integrated Queue Solution v3.14"); // I had to, sorry
        pl("-------------------------------------------------");

        char ch = 'a';
        while(ch != 'q') {
            p("\n[e]nqueue, [d]equeue, [i]nfo, [q]uit | enter choice: ");
            ch = sc.next().charAt(0);

            switch(ch) {
                case 'e':
                enq(); break;
                case 'd':
                deq(); break;
                case 'i':
                info(); break;
                case 'q':
                break;
            }

            if(f == size) { 
                pl("-------------------------------------------------"); 
                pl("\no noes\ndis q is kill\nPlease order a new one.\nStats at time of death:\n");
                break; 
            }
        }
        
        info();
        p("\nTo infinity and beyond!");
    }

    void p(String s) { System.out.print(s + ""); }

    void pl(String s) { System.out.println(s + ""); }    
}
