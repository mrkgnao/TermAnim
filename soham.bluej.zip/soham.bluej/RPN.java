import java.util.Scanner;

public class RPN
{
    String cleanUp(final String s) {
        // Remove all chars that are not digits or operators.
        String ret = "";
        for (char i : s.toCharArray()) { 
            if("0123456789+-*/ ".indexOf(i) != -1) ret += i;
        }
        return ret;
    }
    
    void main() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter expression: ");
        String[] in = cleanUp(sc.nextLine()).split("\\s+");
        int count = 0, len = in.length;
        
        Stack st = new Stack(len);
        
        while(count < len) {
            String cur = in[count];
            if("+-/*".indexOf(cur) != -1) {
                st.disp();
                System.out.println("Operation: " + cur);
                int a = st.pop(), b = st.pop();
                int res = 0;
                
                switch(cur) {
                    case "+": res = a + b; break;
                    case "-": res = a - b; break;
                    case "*": res = a * b; break;
                    case "/": res = a / b; break;
                }
                st.push(res);
            } else {
                st.push(Integer.parseInt(cur));
            }
            
            ++count;
        }
        
        System.out.println("The result of the calculation is: " + st.pop());
    }
}
