import java.util.Scanner;
import java.util.ArrayList;

class Matrix {
    double[][] arr;
    int rows, cols;

    static Scanner sc = new Scanner(System.in);
    
    static String help = 
              "                                    Advanced Matrix Package v0.1\n"
            + "----------------------------------------------------------------------------------------------------------\n"
            + "(I was feeling jobless, as always.\n"
            + "Plus, it was a nice way to familiari[sz]e myself with the mysteries of the hallowed DDA.)\n\n"
            
            + "You can add, subtract, multiply, divide and exponentiate matrices with the functions in this package.\n"
            + "There are 26 memory locations or registers, from A to Z. Each can store a matrix.\n"
            + "Out of these, three are \"special registers\":\n"
            + "    - A stores the answer of the last calculation.\n"
            + "    - I stores an identity matrix.\n"
            + "    - Z stores a zero matrix.\n"
            + "The other 23 are called \"user registers\" and can be freely modified by the user.\n\n"
            
            + "Some things to keep in mind:\n"
            + "    - All math operations work on matrices stored in registers.\n"
            + "      If you want to, say, add two matrices of your choice, use the input() function to store them into two separate registers first!\n"
            + "    - All math operations store their results into register A. This will be lost if you perform another calculation.\n"
            + "      You can copy one register into another using the store() function.\n"
            + "      This can be used to store the result of a calculation safely in one of the user registers.\n\n"
            
            + "The program is very easy to break as of now. There is almost no error handling yet.\n"
            + "Plus, I don't really know anything about string formatting so matrices look really ugly when printed. Sorry.\n"
            + "----------------------------------------------------------------------------------------------------------\n";

    Matrix(int m, int n) {
        arr = new double[m][n];
        this.rows = m;
        this.cols = n;
    }

    // Core functions --------------------------------------------------------------------------------------------------------------
    
    static Matrix add(Matrix A, Matrix B) {
        int m = A.rows, n = A.cols;
        Matrix ret = zero(m, n);

        for(int i = 0; i < m; ++i) {
            for(int j = 0; j < n; ++j) {
                ret.arr[i][j] = A.arr[i][j] + B.arr[i][j];
            } 
        }

        return ret;
    }

    static Matrix neg(Matrix A) {
        int m = A.rows, n = A.cols;
        Matrix ret = zero(m, n);

        for(int i = 0; i < m; ++i) {
            for(int j = 0; j < n; ++j) {
                ret.arr[i][j] = -A.arr[i][j];
            } 
        }

        return ret;
    }

    static Matrix sub(Matrix A, Matrix B) {
        return add(A, neg(B));
    }

    static Matrix mul(Matrix A, Matrix B) {
        int m = A.rows, n = A.cols; // everything is square
        Matrix ret = zero(m, n);

        for(int i = 0; i < m; ++i) {
            for(int j = 0; j < n; ++j) {
                // ret.arr[i][j] = (ith row of A) dot (jth column of B)
                // dotting is O(n), so the whole thing is O(n^3)
                // I don't know Strassen.

                for(int k = 0; k < m; ++k) {
                    ret.arr[i][j] += A.arr[i][k] * B.arr[k][j];
                }
            }
        }

        return ret;
    }
    
    static Matrix pow(Matrix A, int p) {
        Matrix ret = id(A.rows);
        
        for(int i = 0; i < p; ++i) {
            ret = mul(ret, A);
        }
        
        return ret;
    }
    
    static Matrix scalarmul(Matrix A, double sc) {
        int m = A.rows, n = A.cols;
        Matrix ret = zero(m, n);

        for(int i = 0; i < m; ++i) {
            for(int j = 0; j < n; ++j) {
                ret.arr[i][j] = sc * A.arr[i][j];
            } 
        }

        return ret;
    }
    
    static double diagSum(Matrix A) {
       int m = A.rows;
       double ret = 0;
       
       for(int i = 0; i < m; ++i) {
           for(int j = 0; j < m; ++j) {
               if(i == j)
                    ret += A.arr[i][j];
           } 
       }
    
       return ret;
    }    
    
    static double antiDiagSum(Matrix A) {
       int m = A.rows;
       double ret = 0;
       
       for(int i = 0; i < m; ++i) {
           for(int j = 0; j < m; ++j) {
               if(i == m - j - 1)
                    ret += A.arr[i][j];
           } 
       }
    
       return ret;
    }       

    static Matrix zero(int m, int n) {
        Matrix ret = new Matrix(m, n);
        for(int i = 0; i < m; ++i) {
            for(int j = 0; j < n; ++j) {
                ret.arr[i][j] = 0;
            }
        }
        return ret;
    }

    static Matrix zero(int n) {
        return zero(n, n);
    }

    static Matrix id(int n) {
        Matrix ret = zero(n);
        for(int i = 0; i < n; ++i) {
            ret.arr[i][i] = 1;
        }
        return ret;
    }
    
    // I/O functions ---------------------------------------------------------------------------------------------------------------

    static Matrix matrixInput(int m, int n) {
        System.out.println("Enter matrix: ");
        Matrix ret = zero(m,n);

        for(int i = 0; i < m; ++i)
            for(int j = 0; j < n; ++j) 
                ret.arr[i][j] = sc.nextDouble();

        return ret;
    }
    
    static Matrix squareMatrixInput(int n) {
        return matrixInput(n, n);
    }
    //─ │ ┌ ┐ └ ┘
    static void print(Matrix in) {
        int m = in.rows, n = in.cols;
        String out = "";
        double d = 0;
        
        U.print("┌");
        U.print(U.repeat(" ", 5 * n - 1));
        U.println("┐");
        
        for(int i = 0; i < m; ++i) {
            U.print("│");
            for(int j = 0; j < n; ++j) {
                d = in.arr[i][j];
                out = String.format("%3.2f", d);
                    
                System.out.print(out);
                if(j != n - 1) U.print(" ");
            }
            U.print("│");
            System.out.println();
        }
        
        U.print("└");
        U.print(U.repeat(" ", 5 * n - 1));
        U.println("┘");
    }

    // Main program -----------------------------------------------------------------------------------------------------------------

    static Matrix findMatrix(char in, Matrix[] mats) {
        int size = mats[0].rows;
        switch(in) {
            case 'I':
            case '1':
                return id(size);
            case 'Z':
            case '0':
                return zero(size);
            case '@':
                return mats[0];
            default:
                return mats[(int)Character.toUpperCase(in) - 65];
        }
    }
    
    static char getChar() {
        while(!sc.hasNext());
        return sc.next().charAt(0);
    }

    static void main() {
        System.out.println(help);
        char ch = ' ';
        System.out.print("Enter size of matrices to be used: ");
        int sz = sc.nextInt();

        Matrix[] mats = new Matrix[26];
        char a, b;
        int p = 0;
        double scalar;
        
        System.out.println();

        //Init the matrix array
        for(int i = 0; i < 10; ++i) {
            mats[i] = new Matrix(sz, sz);
        }

        while(ch != 'q') {
            System.out.print("[i]nput, [a]dd, [s]ubtract, [m]ultiply, s[c]alar multiply, [e]xponentiate, [p]rint, s[t]ore, [q]uit, [d]iagonal sum, a[n]tidiagonal sum\n"
                           + "Enter choice: ");
            ch = getChar();
            
            if("asm".indexOf(ch) != -1) {
                System.out.print("Enter first matrix (A-Z): ");
                a = getChar();                    
                System.out.print("Enter second matrix (A-Z): ");
                b = getChar();
                    
                switch(ch) {
                    case 'a':
                        mats[0] = add(findMatrix(a, mats), findMatrix(b, mats));
                        break;
                    case 's':
                        mats[0] = sub(findMatrix(a, mats), findMatrix(b, mats)); 
                        break;
                    case 'm':
                        mats[0] = mul(findMatrix(a, mats), findMatrix(b, mats)); 
                        break;
                }
                
                print(mats[0]);
            } else { // unary or nonary
                switch(ch) {
                    case 'i':
                        System.out.print("Enter matrix to store into (A-Z): ");
                        b = getChar();
                        mats[b - 65] = squareMatrixInput(sz);
                        break;
                        
                    case 'p':
                        System.out.print("Enter matrix to print (A-Z): ");
                        a = getChar();                          
                        print(findMatrix(a, mats));
                        break;
                    case 't':
                        System.out.print("Enter matrix to store (A-Z): ");
                        a = getChar();                    
                        System.out.print("Enter matrix to store into (A-Z): ");
                        b = getChar();
                        if("AIZ".indexOf(b) != -1) {
                            switch(b) {
                                case 'A': System.out.println("Error: Cannot store into answer matrix."); break;
                                case 'I': System.out.println("Error: Cannot store into identity matrix."); break;
                                case 'Z': System.out.println("Error: Cannot store into zero matrix."); break;
                            }
                            break;
                        }
                        mats[b - 65] = findMatrix(b, mats);
                        break;
                    case 'c':
                        System.out.print("Enter matrix to multiply by the scalar (A-Z): ");
                        a = getChar();
                        System.out.print("Enter scalar: ");
                        scalar = sc.nextDouble();
                        mats[0] = scalarmul(findMatrix(a, mats), scalar);
                        print(mats[0]);
                        break;
                    case 'd':
                        System.out.print("Enter matrix to find the diagonal sum of (A-Z): ");
                        a = getChar();
                        System.out.println("The diagonal sum of " + a + ": " + diagSum(findMatrix(a, mats)));
                        break;
                    case 'n':
                        System.out.print("Enter matrix to find the antidiagonal sum of (A-Z): ");
                        a = getChar();
                        System.out.println("The antidiagonal sum of " + a + ": " + antiDiagSum(findMatrix(a, mats))); 
                        break;
                    case 'e':
                        System.out.print("Enter matrix to exponentiate (A-Z): ");
                        a = getChar();
                        System.out.print("Enter exponent: ");
                        p = sc.nextInt();
                        mats[0] = pow(findMatrix(a, mats), p);
                        print(mats[0]);
                        break;
                    case 'q':
                        break;
                }
            }
            System.out.print("\n");
        }
    }
}