public class TimeCheck {
    void main() {
        long time = 0;
        double total = 0;
        for(int i = 0; i < 1000; ++i) {
            time = System.nanoTime();
            System.out.println(
                U.repeat(
                    U.repeat('.', 168) + "\n", 
                    32)
                );
            System.out.print("\u000C");
            total += (System.nanoTime() - time);
        }
        System.out.println(
            "It takes " + 
            ((total / 1000)/(10e9)) + 
            "s to print and clear the screen once on this system");
    }
}
