public class ReverseString
{
    String reverse(String in)
    {
        Stack st = new Stack(in.length());
        for(char i : in.toCharArray()) {
            st.push(i);
        }
        String rev = "";
        while(!st.empty()) rev += (char)st.pop();
        return rev;
    }
}
