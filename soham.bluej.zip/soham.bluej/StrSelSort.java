import java.util.Scanner;

public class StrSelSort {
    static String[] sort(final String[] in, final boolean debug) {
        String[] cpy = in;   // arrays are passed by reference, don't modify the input
        int len = in.length, minpos = 0;
        String swap = "", min = "";

        //Main loop
        for(int i = 0; i < len; ++i) {
            min = cpy[i];
            for(int j = i + 1; j < len; ++j) {
                if(cpy[j].compareTo(min) < 0) { 
                    // update min to be the "lowest" string so far
                    min = cpy[j];
                    minpos = j;
                }
                                
                if(debug) {
                    Utils.print("i " + i + ", j: " + j + ", min: " + min + ", array: ");
                    Utils.printStrArray(cpy);
                }
            }
            swap = cpy[minpos];
            cpy[minpos] = cpy[i];
            cpy[i] = swap;
            
        }
        return cpy;
    }
}
