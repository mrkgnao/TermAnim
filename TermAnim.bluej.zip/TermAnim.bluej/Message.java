interface Message {
    String msg();
}