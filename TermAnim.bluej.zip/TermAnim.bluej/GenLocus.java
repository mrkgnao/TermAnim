interface GenLocus {
    String msg();
    char onLocus(int x, int y, int t);
}