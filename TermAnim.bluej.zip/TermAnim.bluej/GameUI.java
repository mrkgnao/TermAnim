public class GameUI {
    static void main() {
        Terminal gameTerm = new Terminal(5, 5000);
        Terminal msgTerm  = new Terminal(10, 5000);
        
        int t = 0;
        
        ShooterGame game   = new ShooterGame(5);
        Animation gameAnim = Animations.convertToAnim(game);
        int level = game.level, lives = game.lives;
        
        msgTerm.displayAndSleep("You are the #, you have to exterminate the @s.", 5000);        
        msgTerm.displayAndSleep("Move the mouse around after this message disappears "
                              + "and see what happens.", 5000);
        msgTerm.fadeOutRandom(50);
        
        while(true) {
            gameTerm.clsPrintSleep(t++, gameAnim);
            if(game.level != level) {
                level = game.level;
                msgTerm.displayAndSleep("You are now level " + level + ".\n"
                                      , 1000);
                msgTerm.fadeOutRandom(50);
            }
            
            if(game.lives != lives) {
                if(game.lives == 0) {
                    msgTerm.displayAndSleep("o noes\nyou are ded", 5000);
                    msgTerm.fadeOutRandom(50);
                } else {
                    lives = game.lives;
                    msgTerm.displayAndSleep("You lost a life!\n"
                                      + "You now have " + lives + " lives.\n"
                                      , 1000);
                    msgTerm.fadeOutRandom(50);
                }
            }
        }
    }
}