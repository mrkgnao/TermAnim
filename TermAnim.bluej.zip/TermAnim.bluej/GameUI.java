public class GameUI {
    static void main() {
        Terminal gameTerm = new Terminal(10, 5000);
        Terminal msgTerm  = new Terminal(10, 5000);
        
        int t = 0;
        
        ShooterGame game   = new ShooterGame(10);
        Animation gameAnim = Animations.convertToAnim(game);
        int level = 0, vel = 0;
        
        msgTerm.displayAndSleep("You are the #, you have to exterminate the @s.", 5000);        
        msgTerm.displayAndSleep("Move the mouse around after this message disappears "
                              + "and see what happens.", 5000);
        msgTerm.fadeOutRandom(50);
        
        while(true) {
            gameTerm.clsPrintSleep(t++, gameAnim);
            if(game.level != level) {
                level = game.level;
                vel = (level + 1);
                msgTerm.displayAndSleep("You are now level " + level + "\n"
                                      + "and can now move at up to " + vel + " u/s"
                                      , 1000);
                msgTerm.fadeOutRandom(50);
            }
        }
    }
}