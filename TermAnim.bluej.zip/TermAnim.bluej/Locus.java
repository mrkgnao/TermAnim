interface Locus {
    String msg();
    boolean onLocus(int x, int y, int t);
}