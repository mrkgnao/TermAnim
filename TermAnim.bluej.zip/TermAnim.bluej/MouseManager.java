import java.awt.MouseInfo;
import java.awt.Point;
import java.lang.Thread;

public class MouseManager {
    static void test() throws InterruptedException {
        Point p = new Point(), cur = new Point();
        String os = U.repeat(U.repeat("o", 168) + "\n", 32);
        while(true) {
            cur = getLoc();
            if(!cur.equals(p)) {
                p = cur;
                System.out.println("\u000C" + os + p);
            }
            Thread.sleep(50);
        }
    }
    
    static Point getLoc() {
        return MouseInfo.getPointerInfo().getLocation();
    }
}
