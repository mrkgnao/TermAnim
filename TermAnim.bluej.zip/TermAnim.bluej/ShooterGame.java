import java.awt.Point;

public class ShooterGame implements GenLocus {
    static final int X_LOC_MIN = 0;
    static final int X_LOC_MAX = 167;
    static final int X_MIN = 9;
    static final int X_MAX = 1345;
    static final int X_PER  = 8;
    
    static final int Y_LOC_MIN = 0;
    static final int Y_LOC_MAX = 31;
    static final int Y_MIN = 62;
    static final int Y_MAX = 682;
    static final int Y_PER  = 20;
    
    static final double RANDOM_SPAWN_PROB = 0.00001;
    
    int xdist = 0;
    int ydist = 0;
    
    int xpos = getLocalX();
    int ypos = getLocalY();
    
    int time = 0;
    
    int[][] playerMissileAt, enemyMissileAt;
    int playerGunX, playerGunY;
    int[][] enemyGunAt;
    
    int hits;
    
    int gunsDestroyed;
    int totalGuns;
    
    int level;
    
    int delayTicks;
    
    public ShooterGame(int delayTicks) {
        this.delayTicks = delayTicks;
        
        playerMissileAt = new int[X_LOC_MAX + 1][Y_LOC_MAX + 1];
        enemyMissileAt  = new int[X_LOC_MAX + 1][Y_LOC_MAX + 1];
        enemyGunAt      = new int[X_LOC_MAX + 1][Y_LOC_MAX + 1];
        
        level = 0;
        
        for(int i = 0; i <= X_LOC_MAX; ++i) {
            for(int j = 0; j <= Y_LOC_MAX; ++j) {
                playerMissileAt[i][j] = 0;
                enemyMissileAt[i][j]  = 0;
            }
        }
        
        // make the guns
        for(int j = 0; j <= Y_LOC_MAX / 2; ++j) {
            if(j % 5 == 0) {
                enemyGunAt[0][j] = 1;
                enemyGunAt[0][Y_LOC_MAX - j] = 1;
                totalGuns += 2;
            }
        }
        
        playerGunX = X_LOC_MAX;
        playerGunY = Y_LOC_MAX / 2;
    }
    
    public String msg() {
        Point  p    = MouseManager.getLoc();
        String ret  = "";
        
        double dist = Math.sqrt(Math.pow(xdist, 2) + Math.pow(ydist, 2));
        double vel  = dist / time;
        
        int xt = (getLocalX() / (X_LOC_MAX / 3)) - 1;
        int yt = (getLocalY() / (Y_LOC_MAX / 3)) - 1;
        
        ret +=    "coords: ("         + U.padLeft(xpos + "", 3)       + ", " + U.padRight(ypos + "", 2)        + ")";
        ret += " || gun pos: ("       + U.padLeft(playerGunX + "", 3) + ", " + U.padRight(playerGunY + "", 2)  + ")"; 
        ret += ", vector: ("          + U.padLeft(xt + "", 2)         + ", " + U.padRight(yt + "", 2)          + ")";
        ret += " || hits: "           + hits;
        ret += ", guns destroyed: "   + gunsDestroyed                 + "/"  + totalGuns;
        ret += " || level: "          + level;
        //ret += ", distance: "       + U.rounded(dist)               + " u";
        //ret += ", avg vel: "        + U.rounded(vel)                + " u/s";
        
        return ret;
    }
    
    public char onLocus(int x, int y, int t) {
        if(time != t) { // gotta do an update!
            updatePlayerGunPos();
            for(int i = 0; i <= Y_LOC_MAX; ++i) { // for each line
                for(int j = 0; j <= X_LOC_MAX; ++j) {
                    // move missiles
                    if(j > 0) { 
                        playerMissileAt[j - 1][i] = playerMissileAt[j][i];
                        enemyMissileAt[X_LOC_MAX - j + 1][i]  = enemyMissileAt[X_LOC_MAX - j][i];
                    }
                    
                    // spawn new missiles
                    if(enemyGunAt[j][i] == 1 && j < X_LOC_MAX && t % 2 == 0) {
                        enemyMissileAt[j + 1][i] = 1;
                    }
                    
                    if(playerGunX == j && playerGunY == i) {
                        if(j > 0 && t % 2 == 0) { // fire a missile
                            playerMissileAt[j - 1][i] = 1;
                        }
                        
                        if(enemyMissileAt[j][i] == 1) {
                            hits++;
                        }
                    }
                    
                    // Random spawning?
                    if(j < X_LOC_MAX / 2 && Math.random() < RANDOM_SPAWN_PROB) {
                        enemyGunAt[j][i] = 1;
                        totalGuns++;
                    }
                    
                    // two missiles colliding destroy each other
                    if(playerMissileAt[j][i] == 1 && enemyMissileAt[j][i] == 1) {
                        playerMissileAt[j][i] = 0;
                        enemyMissileAt[j][i]  = 0;
                    }
                    
                    // player missiles destroy guns
                    if(playerMissileAt[j][i] == 1 && enemyGunAt[j][i] == 1) {
                        playerMissileAt[j][i] = 0;
                        enemyGunAt[j][i]      = 0;
                        gunsDestroyed++;
                        
                        if(gunsDestroyed > 5 * level * level) level++;
                    }
                }
                // clear the rightmost char of each line
                playerMissileAt[X_LOC_MAX][i] = 0;
            }
        }
        
        // where is the mouse? ----------------------------------------------
        
        int _xpos = getLocalX(), _ypos = getLocalY();
        
        boolean xOutOfRange = !xOk(_xpos);
        boolean yOutOfRange = !yOk(_ypos);
        boolean inRange = !(xOutOfRange || yOutOfRange);
        
        Point p = MouseManager.getLoc();
        xdist += Math.abs(xpos - _xpos);
        ydist += Math.abs(ypos - _ypos);
        xpos = _xpos;
        ypos = _ypos;
        time = t;
        
        // within X_PER of mouse position?
        boolean xOk = xpos == x;
        boolean yOk = ypos == y;
        
        // ------------------------------------------------------------------
        
        if(!inRange) return ' ';
        
        if(playerMissileAt[x][y] != 0)         return '<';
        if(enemyMissileAt[x][y]  != 0)         return '>';
        if(enemyGunAt[x][y]      != 0)         return '@';
        if(playerGunX == x && playerGunY == y) return '#';
        
        return ' ';
    }
    
    public int getLocalX() {
        return (MouseManager.getLoc().x - X_MIN) / X_PER;
    }
    
    public int getLocalY() {
        return (MouseManager.getLoc().y - Y_MIN) / Y_PER;
    }
    
    public boolean xOk(int _x) {
        return !(_x < X_LOC_MIN || _x > X_LOC_MAX);
    }
    
    public boolean yOk(int _y) {
        return !(_y < Y_LOC_MIN || _y > Y_LOC_MAX);
    }
    
    public void updatePlayerGunPos() {
        int xt = (level + 1) * (int)Math.signum((getLocalX() / (X_LOC_MAX / 3)) - 1);
        int yt = (level + 1) * (int)Math.signum((getLocalY() / (Y_LOC_MAX / 3)) - 1);
        
        if(xOk(playerGunX + xt)) playerGunX += xt;
        if(yOk(playerGunY + yt)) playerGunY += yt;
    }
}
