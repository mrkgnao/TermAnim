import java.awt.Point;

public class ShooterGame implements GenLocus {
    static final int X_LOC_MIN = 0;
    static final int X_LOC_MAX = 167;
    static final int X_MIN = 9;
    static final int X_MAX = 1345;
    static final int X_PER  = 8;

    static final int Y_LOC_MIN = 0;
    static final int Y_LOC_MAX = 31;
    static final int Y_MIN = 62;
    static final int Y_MAX = 682;
    static final int Y_PER  = 20;

    static final double RANDOM_SPAWN_PROB = 0.00001;

    int xdist = 0;
    int ydist = 0;

    int xpos = getLocalX();
    int ypos = getLocalY();

    int time = 0;

    int[][] playerMissileAt, enemyMissileAt;
    int playerGunX, playerGunY;
    int[][] enemyGunAt;

    int hits;

    int gunsDestroyed;
    int totalGuns;

    int level;
    int lives;

    // fire rate
    int playerFireRate;
    int enemyFireRate;

    // hehehe
    static final int MIN_PLAYER_FIRE_RATE = 10;
    static final int MIN_ENEMY_FIRE_RATE  = 20;

    // missile velocities also change!
    int playerMissileVel;
    int enemyMissileVel;

    static final int MIN_PLAYER_MISSILE_VEL = 3;
    static final int MIN_ENEMY_MISSILE_VEL  = 3;

    static final int MAX_LIVES = 5;
    static final int MAX_VEL   = 10;

    int delayTicks;
    int tick;

    int enemyMotionRange;
    int enemyMotionRate;
    static final int MIN_ENEMY_MOTION_RANGE = 0;
    static final int MAX_ENEMY_MOTION_DELAY = 1;

    String localMsg = "";

    public ShooterGame(int delayTicks) {
        this.delayTicks = delayTicks;

        playerMissileAt = new int[X_LOC_MAX + 1][Y_LOC_MAX + 1];
        enemyMissileAt  = new int[X_LOC_MAX + 1][Y_LOC_MAX + 1];
        enemyGunAt      = new int[X_LOC_MAX + 1][Y_LOC_MAX + 1];

        level = 0;
        lives = MAX_LIVES;

        playerFireRate = MIN_PLAYER_FIRE_RATE;
        enemyFireRate  = MIN_ENEMY_FIRE_RATE;
        playerMissileVel = MIN_PLAYER_MISSILE_VEL;
        enemyMissileVel = MIN_ENEMY_MISSILE_VEL;

        enemyMotionRange = MIN_ENEMY_MOTION_RANGE;
        enemyMotionRate  = 0;
        tick = 0;

        for(int i = 0; i <= X_LOC_MAX; ++i) {
            for(int j = 0; j <= Y_LOC_MAX; ++j) {
                playerMissileAt[i][j] = 0;
                enemyMissileAt[i][j]  = 0;
            }
        }

        // make the guns
        for(int j = 0; j <= Y_LOC_MAX / 3; ++j) {
            if(j % 4 == 0) {
                enemyGunAt[0][j] = 1;
                enemyGunAt[0][Y_LOC_MAX - j] = 1;
                totalGuns += 2;
            }
        }

        playerGunX = X_LOC_MAX;
        playerGunY = Y_LOC_MAX / 2;
    }

    public String msg() {
        Point  p    = MouseManager.getLoc();
        String ret  = localMsg;

        double dist = Math.sqrt(Math.pow(xdist, 2) + Math.pow(ydist, 2));
        double vel  = dist / time;

        int xt = (getLocalX() / (X_LOC_MAX / 3)) - 1;
        int yt = (getLocalY() / (Y_LOC_MAX / 3)) - 1;

        ret +=    "coords: ("        + U.padLeft(xpos + "", 3)       + ", " + U.padLeft(ypos + "", 2)        + ")";
        ret += " | gun pos: ("       + U.padLeft(playerGunX + "", 3) + ", " + U.padLeft(playerGunY + "", 2)  + ")"; 
        ret += ", vector: ("         + U.padLeft(xt + "", 2)         + ", " + U.padLeft(yt + "", 2)          + ")";
        ret += " | hits: "           + hits;
        ret += ", guns destroyed: "  + gunsDestroyed                 + "/"  + totalGuns;
        ret += " | level: "          + level;
        ret += ", lives: "           + U.padLeft(U.repeat("♥", lives), MAX_LIVES);
        ret += ", EMR: "             + enemyMotionRange;
        //ret += ", distance: "       + U.rounded(dist)               + " u";
        //ret += ", avg vel: "        + U.rounded(vel)                + " u/s";

        return ret;
    }

    public char onLocus(int x, int y, int t) {
        // --------------------------------------------------------------------------------------
        // Main game state update loop. Four nouns in a row.
        // --------------------------------------------------------------------------------------
        if(time != t) { 
            movePlayerGun(Math.max(1, level / 2));
            for(int i = 0; i <= Y_LOC_MAX; ++i) { // for each line
                for(int j = 0; j <= X_LOC_MAX; ++j) {

                    // --------------------------------------------------------------------------------------
                    // new guns spawn randomly
                    // --------------------------------------------------------------------------------------

                    if(level > 1 && j < X_LOC_MAX / 2 && Math.random() < RANDOM_SPAWN_PROB) {
                        enemyGunAt[j][i] = 1;
                        totalGuns++;
                    }

                    // --------------------------------------------------------------------------------------
                    // missiles destroy each other on colliding
                    // --------------------------------------------------------------------------------------

                    if(playerMissileAt[j][i] == 1 && enemyMissileAt[j][i] == 1) {
                        playerMissileAt[j][i] = 0;
                        enemyMissileAt[j][i]  = 0;
                    }

                    // --------------------------------------------------------------------------------------
                    // player missiles destroy guns
                    // --------------------------------------------------------------------------------------

                    if(playerMissileAt[j][i] == 1 && enemyGunAt[j][i] == 1) {
                        playerMissileAt[j][i] = 0;
                        enemyGunAt[j][i]      = 0;
                        gunsDestroyed++;

                        // level up
                        if(gunsDestroyed >= 5 * level * (level + 2)) {
                            level++;

                            playerFireRate++;
                            enemyFireRate++;

                            playerMissileVel++;
                            enemyMissileVel++;

                            if(level == 1) {
                                enemyMotionRate = 3;
                                enemyMotionRange = 3;
                            }

                            enemyMotionRate++;
                            enemyMotionRange++;
                        }
                    }

                    // --------------------------------------------------------------------------------------
                    // move missiles
                    // --------------------------------------------------------------------------------------

                    if(j >= playerMissileVel) {
                        playerMissileAt[j - playerMissileVel][i] = playerMissileAt[j][i];

                        boolean flag = false;

                        if(playerMissileAt[j - playerMissileVel][i] == 1) {
                            for(int k = 0; k <= playerMissileVel; ++k) {
                                if(enemyMissileAt[j - k][i] == 1) { 
                                    enemyMissileAt[j - k][i] = 0;
                                    flag = true; 
                                    break;
                                }
                            }
                            if(flag) playerMissileAt[j - playerMissileVel][i] = 0;
                        }

                        playerMissileAt[j][i] = 0;
                    }

                    if(j >= enemyMissileVel) {
                        enemyMissileAt[X_LOC_MAX - j + enemyMissileVel][i]  = enemyMissileAt[X_LOC_MAX - j][i];

                        boolean flag = false;
                        if(enemyMissileAt[X_LOC_MAX - j + enemyMissileVel][i] == 1) {
                            for(int k = 0; k <= enemyMissileVel; ++k) {
                                if(playerMissileAt[X_LOC_MAX - j + k][i] == 1) { 
                                    playerMissileAt[X_LOC_MAX - j + k][i] = 0;
                                    flag = true; 
                                    break;
                                }
                            }
                            if(flag) enemyMissileAt[X_LOC_MAX - j + enemyMissileVel][i] = 0;
                        }

                        enemyMissileAt[X_LOC_MAX - j][i] = 0;
                    }

                    // --------------------------------------------------------------------------------------
                    // spawn new missiles
                    // --------------------------------------------------------------------------------------

                    if(enemyGunAt[j][i] == 1 && j < X_LOC_MAX && t % enemyFireRate == 0) {
                        enemyMissileAt[j + 1][i] = 1;
                    }

                    if(playerGunX == j && playerGunY == i) {
                        if(j >= playerMissileVel && t % playerFireRate == 0) { // fire a missile
                            playerMissileAt[j - playerMissileVel][i] = 1;
                        }

                        // get hit
                        if(enemyMissileAt[j][i] == 1) {
                            hits++;
                            enemyMissileAt[j][i] = 0;

                            if(hits > 2 * level) {
                                // op is ded [sic]
                                lives--;
                                hits = 0;
                            }
                        }
                    }
                    // --------------------------------------------------------------------------------------
                    // move enemy guns around
                    // --------------------------------------------------------------------------------------

                    if(enemyMotionRange != 0) {
                        if((t - 1) % 10 == 0) {
                            for(int k = 0; k <= Y_LOC_MAX / 3; ++k) {
                                if(k % 4 == 0) {
                                    int lim = 2 * enemyMotionRange;
                                    for(int m = 0; m <= enemyMotionRange; ++m) {
                                        if((t + m) % lim == 0 || (t - m) % lim == 0) {
                                            enemyGunAt[m][k + m] = 1;
                                            enemyGunAt[m][Y_LOC_MAX - k - m] = 1;
                                            localMsg = m + " ";
                                        } else {
                                            enemyGunAt[m][k + m] = 0;
                                            enemyGunAt[m][Y_LOC_MAX - k - m] = 0;
                                        }
                                    }
                                }
                            }
                        }
                    }

                }

                // clear the rightmost char of each line
                playerMissileAt[X_LOC_MAX][i] = 0;
            }
        }

        // where is the mouse? ----------------------------------------------

        int _xpos = getLocalX(), _ypos = getLocalY();

        boolean xOutOfRange = !xOk(_xpos);
        boolean yOutOfRange = !yOk(_ypos);
        boolean inRange = !(xOutOfRange || yOutOfRange);

        Point p = MouseManager.getLoc();
        xdist += Math.abs(xpos - _xpos);
        ydist += Math.abs(ypos - _ypos);
        xpos = _xpos;
        ypos = _ypos;
        time = t;

        // within X_PER of mouse position?
        boolean xOk = xpos == x;
        boolean yOk = ypos == y;

        // ------------------------------------------------------------------

        if(!inRange) return ' ';

        if(playerMissileAt[x][y] != 0)         return '<';
        if(enemyMissileAt[x][y]  != 0)         return '>';
        if(enemyGunAt[x][y]      != 0)         return '@';
        if(playerGunX == x && playerGunY == y) return '#';

        return ' ';
    }

    public int getLocalX() {
        return (MouseManager.getLoc().x - X_MIN) / X_PER;
    }

    public int getLocalY() {
        return (MouseManager.getLoc().y - Y_MIN) / Y_PER;
    }

    public boolean xOk(int _x) {
        return !(_x < X_LOC_MIN || _x > X_LOC_MAX);
    }

    public boolean yOk(int _y) {
        return !(_y < Y_LOC_MIN || _y > Y_LOC_MAX);
    }

    public void movePlayerGun(int multiplier) {
        int xt = multiplier * (int)Math.signum((getLocalX() / (X_LOC_MAX / 3)) - 1);
        int yt = multiplier * (int)Math.signum((getLocalY() / (Y_LOC_MAX / 3)) - 1);

        if(xOk(playerGunX + xt)) playerGunX += xt;
        if(yOk(playerGunY + yt)) playerGunY += yt;
    }
}
