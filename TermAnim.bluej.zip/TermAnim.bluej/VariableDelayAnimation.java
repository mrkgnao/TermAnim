interface VariableDelayAnimation extends Animation {
    int delay(int t);
}