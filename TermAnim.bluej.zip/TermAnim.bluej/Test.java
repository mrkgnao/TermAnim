public class Test {
    static void main() {
        U.sleep(1000);
        for(int i = 0; i < 16; ++i) {
            System.out.print(i + ": abcd");
            U.sleep(500);
            System.out.print(Character.toString((char)(i == 12 ? 0 : i)) + ""+Character.toString((char)(i == 12 ? 0 : i))+ "asdf\n");
        }
        System.out.print("asdf");
        U.sleep(500);
        System.out.print("\basds");
    }
}
