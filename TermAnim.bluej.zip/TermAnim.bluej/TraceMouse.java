import java.awt.Point;

public class TraceMouse implements Locus {
    static final int X_LOC_MIN = 0;
    static final int X_LOC_MAX = 167;
    static final int X_MIN = 9;
    static final int X_MAX = 1345;
    static final int X_PER  = 8;
    
    static final int Y_LOC_MIN = 0;
    static final int Y_LOC_MAX = 31;
    static final int Y_MIN = 62;
    static final int Y_MAX = 682;
    static final int Y_PER  = 20;
    
    int xdist = 0;
    int ydist = 0;
    
    int xpos = getLocalX();
    int ypos = getLocalY();
    
    int time = 0;
    
    int[][] lastVisitTime;
    
    int delayTicks;
    
    public TraceMouse(int delayTicks) {
        this.delayTicks = delayTicks;
        lastVisitTime = new int[X_LOC_MAX + 1][Y_LOC_MAX + 1];
        for(int i = 0; i <= X_LOC_MAX; ++i) {
            for(int j = 0; j <= Y_LOC_MAX; ++j) {
                lastVisitTime[i][j] = -1;
            }
        }
    }
    
    public String msg() { 
        Point p = MouseManager.getLoc();
        String ret = "";
        double dist = Math.sqrt(Math.pow(xdist, 2) + Math.pow(ydist, 2));
        double vel = dist / time;
        ret += "coords: apparent (" + U.padLeft(xpos + "", 3)  + ", " + U.padLeft(ypos + "", 2)  + ")";
        ret += ", true ("           + U.padLeft(p.x + "", 4)   + ", " + U.padLeft(p.y + "", 3)   + ")";
        ret += ", distance: "       + U.rounded(dist) + " u";
        ret += ", avg vel: "        + U.rounded(vel) + " u/s";
        
        return ret;
    }
    
    public boolean onLocus(int x, int y, int t) {
        int _xpos = getLocalX(), _ypos = getLocalY();
        
        boolean xOutOfRange = _xpos < X_LOC_MIN || _xpos > X_LOC_MAX;
        boolean yOutOfRange = _ypos < Y_LOC_MIN || _ypos > Y_LOC_MAX;
        
        Point p = MouseManager.getLoc();
        xdist += Math.abs(xpos - _xpos);
        ydist += Math.abs(ypos - _ypos);
        xpos = _xpos;
        ypos = _ypos;
        time = t;
        
        // within X_PER of mouse position?
        boolean xOk = Math.abs(xpos - x) == 0;
        boolean yOk = Math.abs(ypos - y) == 0 ;
        
        if(xOk && yOk && !(xOutOfRange || yOutOfRange)) {
            // pointer is there, update time
            lastVisitTime[xpos][ypos] = t;            
        }
        
        boolean unvisited = lastVisitTime[x][y] == -1;
        return (!unvisited) && ((t - lastVisitTime[x][y]) <= delayTicks);
    }
    
    public int getLocalX() {
        return (MouseManager.getLoc().x - X_MIN) / X_PER;
    }
    
    public int getLocalY() {
        return (MouseManager.getLoc().y - Y_MIN) / Y_PER;
    }
}
