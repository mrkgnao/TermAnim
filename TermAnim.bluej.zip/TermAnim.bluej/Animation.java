interface Animation {
    String msg();
    String frame(int t);
}